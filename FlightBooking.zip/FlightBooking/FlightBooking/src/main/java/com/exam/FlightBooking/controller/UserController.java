package com.exam.FlightBooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.FlightBooking.model.User;
import com.exam.FlightBooking.service.UserService;



@RestController
@CrossOrigin(origins ="http://localhost:4200")
public class UserController {

	
	@Autowired
	private UserService service;
	
	@PostMapping("/registeruser")
	//to save user in data and if user is already in database
	public User registerUser(@RequestBody User user) throws Exception {
		String tempEmail = user.getEmail();
		
		if(tempEmail != null && !"".equals(tempEmail)) {
			User userObj =service.fetchUserByEmail(tempEmail);
			
			if(userObj !=null) {
				throw new Exception("User with " +tempEmail +" Id is already regsitered");
			}
		}
		User userobj = null;
		userobj= service.saveUser(user);
		return userobj;
	}

	@PostMapping("/login")

	public User loginUser(@RequestBody User user) throws Exception {
		String tempEmailId = user.getEmail();
		String temppassword = user.getPassword();
		User userObj = null;
		if(tempEmailId !=null && temppassword !=null) {
			userObj =service.fetchUserByEmailAndPassword(tempEmailId, temppassword);
		}
		if(userObj==null) {
			throw new Exception("Invalid Credential");
		}
		return userObj;
	}
}
