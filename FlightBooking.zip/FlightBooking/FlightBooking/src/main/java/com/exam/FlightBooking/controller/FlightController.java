package com.exam.FlightBooking.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.FlightBooking.model.Flight;
import com.exam.FlightBooking.repository.FlightRepository;


@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class FlightController {
	
	@Autowired
	private FlightRepository flightrepo;
	
	//get all the products.
		@GetMapping("/flights")
		public List<Flight> getAllFlights(){
			
			return flightrepo.findAll();
			
		}
		
		//create method
		@PostMapping("/flights")
		public Flight createFlight(@RequestBody Flight flight) {
			return flightrepo.save(flight);
		}

		
		//get product by id
		@GetMapping("/flights/{id}")
		public ResponseEntity<Optional<Flight>> getFlightById(@PathVariable Long id) {
			Optional<Flight> flight = flightrepo.findById(id);
			return ResponseEntity.ok(flight);
		}
		
		//update product
		@PutMapping("/flights/{id}")
		public ResponseEntity<Flight> updateFlight(@PathVariable Long id, @RequestBody Flight flightdetails){
			Flight flight = flightrepo.findById(id).get();
			flight.setFlight_name(flightdetails.getFlight_name());
			flight.setFlight_source(flightdetails.getFlight_source());
			flight.setFlight_destination(flightdetails.getFlight_destination());
			flight.setFlight_fare(flightdetails.getFlight_fare());
			
			Flight updateflight = flightrepo.save(flight);
			return ResponseEntity.ok(updateflight);
		}
		
		@DeleteMapping(value="/flights/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteFlight(@PathVariable Long id){
			Flight flight = flightrepo.findById(id).get();
			flightrepo.delete(flight);
			Map<String,Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
			
		}
		

}
