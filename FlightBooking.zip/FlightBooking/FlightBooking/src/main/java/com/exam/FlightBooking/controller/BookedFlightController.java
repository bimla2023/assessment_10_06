package com.exam.FlightBooking.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.exam.FlightBooking.model.BookedFlight;

import com.exam.FlightBooking.repository.BookedFlightRepository;


@CrossOrigin(origins ="http://localhost:4200")
@RestController
public class BookedFlightController {
	
	@Autowired
	private BookedFlightRepository bookedflightrepo;
	
			@GetMapping("/bookedflights")
			public List<BookedFlight> getAllBookedFlights(){
				
				return bookedflightrepo.findAll();
				
			}
	
			//create method
			@PostMapping("/bookedflights")
			public BookedFlight createFlight(@RequestBody BookedFlight bookedflight) {
				return bookedflightrepo.save(bookedflight);
			}

			
			//get product by id
			@GetMapping("/bookedflights/{id}")
			public ResponseEntity<Optional<BookedFlight>> getBookedFlightById(@PathVariable Long id) {
				Optional<BookedFlight> bookedflight = bookedflightrepo.findById(id);
				return ResponseEntity.ok(bookedflight);
			}
			
			//update product
			@PutMapping("/bookedflights/{id}")
			public ResponseEntity<BookedFlight> updateBookedFlight(@PathVariable Long id, @RequestBody BookedFlight bookedflightdetails){
				BookedFlight bookedflight = bookedflightrepo.findById(id).get();
				bookedflight.setFlight_name(bookedflightdetails.getFlight_name());
				bookedflight.setFlight_source(bookedflightdetails.getFlight_source());
				bookedflight.setFlight_destination(bookedflightdetails.getFlight_destination());
				bookedflight.setFlight_fare(bookedflightdetails.getFlight_fare());
				
				
				BookedFlight updateBookedflight = bookedflightrepo.save(bookedflight);
				return ResponseEntity.ok(updateBookedflight);
			}
			
			
			@DeleteMapping("/bookedflights/{id}")
			public ResponseEntity<Map<String, Boolean>> deleteBookedFlight(@PathVariable Long id){
				BookedFlight bookedflight = bookedflightrepo.findById(id).get();
				bookedflightrepo.delete(bookedflight);
				Map<String,Boolean> response = new HashMap<>();
				response.put("deleted", Boolean.TRUE);
				return ResponseEntity.ok(response);
				
			}
	
	
	
}
