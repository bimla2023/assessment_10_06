package com.exam.FlightBooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.FlightBooking.model.User;
import com.exam.FlightBooking.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository repository;

	public User saveUser(User user) {
		return repository.save(user);
	}

	// to check user is in database or not
	public User fetchUserByEmail(String email) {

		return repository.findByEmail(email);
	}

	public User fetchUserByEmailAndPassword(String email, String password) {

		return repository.findByEmailAndPassword(email, password);
	}

}
