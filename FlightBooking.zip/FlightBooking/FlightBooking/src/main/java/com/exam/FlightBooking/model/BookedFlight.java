package com.exam.FlightBooking.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="bookedflight_table")
public class BookedFlight {
	
	@Id
	@Column(name="flight_id")
	private long flight_id;
	@Column(name="flight_name")
	private String flight_name;
	@Column(name="flight_source")
	private String flight_source;
	@Column(name="flight_destination")
	private String flight_destination;
	@Column(name="flight_fare")
	private int flight_fare;

	
	public BookedFlight() {
		
	}


	public BookedFlight(long flight_id, String flight_name, String flight_source, String flight_destination,
			int flight_fare) {
		super();
		this.flight_id = flight_id;
		this.flight_name = flight_name;
		this.flight_source = flight_source;
		this.flight_destination = flight_destination;
		this.flight_fare = flight_fare;
	}


	public long getFlight_id() {
		return flight_id;
	}


	public void setFlight_id(long flight_id) {
		this.flight_id = flight_id;
	}


	public String getFlight_name() {
		return flight_name;
	}


	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}


	public String getFlight_source() {
		return flight_source;
	}


	public void setFlight_source(String flight_source) {
		this.flight_source = flight_source;
	}


	public String getFlight_destination() {
		return flight_destination;
	}


	public void setFlight_destination(String flight_destination) {
		this.flight_destination = flight_destination;
	}


	public int getFlight_fare() {
		return flight_fare;
	}


	public void setFlight_fare(int flight_fare) {
		this.flight_fare = flight_fare;
	}


	
	

}
